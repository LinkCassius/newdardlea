module.exports = {
  database:
    "databasetest",
  //database: "mongodb://localhost:27017/dardlea_local",
};
