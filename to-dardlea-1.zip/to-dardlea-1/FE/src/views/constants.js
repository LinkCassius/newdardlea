export const MAP_CENTER_COORDINATES = [1.81881, 38.16596];
export const MAP_ZOOM = 3;
export const MAP_MAX_ZOOM = 18;
