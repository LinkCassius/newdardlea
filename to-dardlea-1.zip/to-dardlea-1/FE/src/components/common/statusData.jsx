exports.statusData = [
  {
    _id: "Active",
    value: "Active",
    name: "Active"
  },
  {
    _id: "InActive",
    value: "InActive",
    name: "InActive"
  }
  // ,
  // {
  //   _id: "Deleted",
  //   value: "Deleted",
  //   name: "Deleted"
  // }
];
